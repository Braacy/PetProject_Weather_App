//
//  Constant.swift
//  WeatherApp
//
//  Created by Владислав  on 24.08.2024.
//

import Foundation


let apiKey = "6edd58c6-3ed4-42c4-ad3c-f65222db08a6"
